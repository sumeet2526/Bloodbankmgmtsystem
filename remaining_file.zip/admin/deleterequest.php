<html>
<head>
	<title>Delete Data</title>

<style>
body{
	
	background-image:url("seamless.jpg");
}
</style>


<body>

<section style="float:left; ">
<div style="float:left;margin-left:50px;"><br>
<b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enter Data to delete request blood</i></b>
<br><br><br><br>
<form action="delete.php" method="post" 
<label>User id:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type='text' name="search" class="tf" placeholder='id' style="width:200px;height:30px;" required><br><br><br>
<label>&nbsp;&nbsp;&nbsp;Name:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type='text' name="search2" class="tf" placeholder='Enter Name' style="width:200px;height:30px;" required><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id="submit-btn" class="btn btn-info" type='submit' align='right' value='Delete Data'><br>
</form>
</div>
</section>
</body>
</head>
